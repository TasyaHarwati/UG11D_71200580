package com.ug11.soal1;

public class UsernameException extends UserException {
    private String username;
    private int jumlahkarakter = 6;

    public String username{
    }
}
