package com.ug11.soal1;

public class LoginException {
}
